/* Other systems declare `struct statfs' et al in <sys/vfs.h>,
   so we have this file to be compatible with programs expecting it.  */

#include <sys/statfs.h>
